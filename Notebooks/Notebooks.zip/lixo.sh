#!/bin/bash

R --max-ppsize=500000
